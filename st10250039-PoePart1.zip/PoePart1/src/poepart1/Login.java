package poepart1;



public class Login {

public String username;
public String password;
public String name;
public String surname;

    public Login (String username, String password)
    {
        this.username = username;
        this.password = password;
    }
    
 
    
    public boolean validateUsername()
    {
        if (username.length() <=5 && username.contains("_"))
        {
            return true;           
        } else {
            return false;
        }
    }
    public static boolean checkUsername(String username)
    {
        return username != null && username.length() <=5 && username.contains("_");
        
    }
    public static boolean validPassword(String password)
    {
        return password != null && password.length()>8 && password.matches("[A-Z]") && password.matches("[a-z]") && password.matches("[!@#$%^&*]") && password.matches("[0-9]");
    }
    
   
    
    public static boolean checkPasswordComplexity(String password)
    {
          
        //regex declared to make sure there are capital ltters, numbers and special characters
         /*
        Title: how to validate password with regular expression
        Author: mkyong
        Date: 5 November 2020
        Code version: 1
        Availability: https://mkyong.com/regular-expressions/how-to-validate-password-with-regular-expression/
        */
        String regex = "^(?=.[A-Z])(?=.\\d)(?=.[@$!%?&])[A-Za-z\\d@$!%*?&]+$";
        //if the password has 8 characters and matches regex 
        
        return (password.length() >= 8 && password.matches(regex));
    }
    
    
    public String Registeruser()
    {
        if (!checkUsername(username))
        {
            return "Format not met! Please contain special characters and atleast 1 Capital letter";
        }  else {
            
        
        if ( checkPasswordComplexity(password))
        {
              return "Password and username successfully captured";
        }  else {
            return "Format not met! Include atleast 8 characters,a capital letter,a special character and a number ";   
        }
       
    }
    }
    
    
    public boolean LoginUser(String username2, String Userpassword )
    {
        if (username2.equals(username) && Userpassword.equals(password))
        {
            return true;
        } else {
            return false;
        }
        
    }
    //return !(!username2.equals(username) || !Userpassword.equals(password)); 
    public String ReturnLoginStatus(boolean loginStatus)
    {
        if (loginStatus){
           return " Welcome back";   // return " Welcome back " + username ";
        } else {
            return "Invalid credentials";
        }
    }
 }

    
    
    
      
    
       


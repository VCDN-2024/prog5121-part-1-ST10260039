package poepart1;

import javax.swing.JOptionPane;
import static poepart1.Login.checkUsername;
import static poepart1.Login.checkPasswordComplexity;


public class PoePart1 {
  public String name;

    public String surname;
    
    public static void main(String[] args) {
     
      
     
        JOptionPane.showMessageDialog(null, "You have to register first in order to login");
         JOptionPane.showMessageDialog(null,"To register please enter the following details");
         String name = JOptionPane.showInputDialog(null, "Enter your name: ");
         String surname = JOptionPane.showInputDialog(null, "Enter your last name: ");
         String username= JOptionPane.showInputDialog(null, "Enter your username: ");
         if (checkUsername(username)){
             JOptionPane.showMessageDialog(null,"Username successfully captured");
         } else {
             JOptionPane.showMessageDialog(null,"Format not met! Please contain special characters and atleast 1 Capital letter");
         }
         
         String password= JOptionPane.showInputDialog(null, "Enter your password: ");
         
         if ( checkPasswordComplexity(password)){
             JOptionPane.showMessageDialog(null,"Username & Password  successfully captured");
         } else {
             JOptionPane.showMessageDialog(null,"Format not met! Include atleast 8 characters,a capital letter,a special character and a number ");
             main(null);
         }
         
         
         
         
         Login user = new Login (username,password);
         JOptionPane.showMessageDialog(null, "To login eter the following details");
         String username2 = JOptionPane.showInputDialog(null, "Please enter your username1: ");
         String Userpassword = JOptionPane.showInputDialog(null, " PLease enter your password: ");
         boolean ReturnLoginStatus = user.LoginUser(username2, Userpassword);
        
         System.out.println(user.ReturnLoginStatus(ReturnLoginStatus));
         
        if (ReturnLoginStatus){
             JOptionPane.showMessageDialog(null,"Welcome back "+ name + surname);
         } else {
             JOptionPane.showMessageDialog(null,"Incorrect password or username");
         }
    }
}




 